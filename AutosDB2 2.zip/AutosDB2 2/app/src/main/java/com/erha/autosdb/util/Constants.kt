package com.erha.autosdb.util

object Constants {

    const val DATABASE_NAME = "games_db"
    const val DATABASE_GAME_TABLE = "game_data_table"
    const val BASEURL = "https://mybackend.com/api"
    const val PORT = 8085


}